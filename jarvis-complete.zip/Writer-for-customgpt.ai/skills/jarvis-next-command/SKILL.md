---
name: jarvis-next-command
description: >
  Advance the current CustomGPT article production session using a structured loop — scope what's
  in-flight, identify the next action for each article, run the right stage, update state. Use this
  skill when the user says "/next", "what should I do next", "advance the workflow", "what's in
  progress", "continue the session", "where did I leave off", or wants to know the status of
  articles currently being produced. Also trigger at the start of any new production session to
  re-establish state before writing begins. This is the orchestration layer that ties all Jarvis
  stages together into a repeatable daily loop.
---

# Jarvis /next — Article Production Loop

The `/next` command is the orchestration layer for the Jarvis production system. It answers
one question at the start of every work session: **what is the highest-leverage action to take
right now, for which article, and why?**

It does not write articles. It manages state, tracks progress, identifies blockers, and
delegates to the right Jarvis stage or skill.

Always read GOALS.md before running /next. Every decision is made against those criteria.

---

## When to Run /next

- At the start of every production session (morning or after a break)
- When you finish one article stage and need to know what to do next
- When you're unsure which article to work on
- When something is blocked and you need to decide how to handle it
- After every 2 to 3 articles to recalibrate priorities

---

## State Files

Jarvis maintains three live state files. Create them if they don't exist.
Reference them at the start of every /next run.

### active.md — What's in-flight right now
```
# Active Articles

| # | Topic | Anchor locked? | Stage | Blocker |
|---|-------|---------------|-------|---------|
| 1 | [topic] | Yes/No | QUEUE/RESEARCH/REVIEW/OUTLINE/WRITE/FAQ/PUBLISH | [blocker or None] |
| 2 | [topic] | Yes/No | [stage] | [blocker or None] |
...
```

### plan.md — Today's topic queue and completion checklist
```
# Today's Plan — [date]

Target: [N] articles

## Queue
- [ ] [Topic 1] — anchor: [one-line anchor or TBD]
- [ ] [Topic 2] — anchor: [one-line anchor or TBD]
- [ ] [Topic 3] — anchor: [one-line anchor or TBD]
- [ ] [Topic 4] — anchor: [one-line anchor or TBD]
- [ ] [Topic 5] — anchor: [one-line anchor or TBD]
- [ ] [Topic 6] — anchor: [one-line anchor or TBD]

## Done today
- [x] [Completed topic] — published [URL]
```

### notes.md — Decisions, patterns, blockers across the session
```
# Session Notes — [date]

## Decisions made
- [decision + reason]

## Patterns observed
- [e.g. "integration articles need more specific version info"]

## Blockers / questions for Luke
- [open question]

## AF failures this session (track for iteration log in GOALS.md)
- [AF-XX failed on topic: reason]
```

---

## The /next Loop (Run Every Time)

### Step 1 — Read state
Load active.md, plan.md, notes.md.
If they don't exist or are empty, ask the user: "What topics are you working on today?"
and build active.md + plan.md from their answer before proceeding.

### Step 2 — Assess AF status for in-flight articles
For each article in active.md, check: which AF criteria from GOALS.md are already satisfied,
which are still open, and whether any blockers exist.

Output a quick status table:

```
## Current State

| Article | Stage | AF satisfied | Blocker |
|---------|-------|-------------|---------|
| [topic] | WRITE | AF-05, AF-08 | Need to verify URL for [claim] |
| [topic] | RESEARCH | AF-08 | No strong anchor found yet |
| [topic] | DONE | All 8 | Published: [URL] |
```

### Step 3 — Identify highest-leverage next action

Score candidate actions using this simple rubric:

| Criterion | Question |
|-----------|----------|
| AF progress | Does this action satisfy or unblock an AF criterion? |
| Batch efficiency | Can this action cover multiple articles at once? |
| Blocking risk | Is there an article that can't advance without this? |
| Time cost | How long will this take? |

**Batch actions always win over single-article actions when possible.**

Examples:
- Research anchors for all 6 topics in one pass > research 1 topic
- Run cannibalization check on today's full queue > check 1 topic
- Approve all outlines before writing any > write one article start to finish

### Step 4 — State the next action clearly

Output format:

```
## /next

**Recommended action:** [Specific action — e.g. "Run SERP Explorer on topics 3, 4, and 5 to find anchors"]
**Why:** [One sentence reason — e.g. "Topics 1 and 2 have anchors locked. 3-5 are blocked at RESEARCH."]
**Time estimate:** [~N minutes]
**AF criteria this unblocks:** [AF-XX, AF-XX]

**After this:** [What to do next — e.g. "Approve all anchors then run Phase A on topic 1"]

**Blockers to resolve:**
- [Blocker 1 — what's needed]
- [Blocker 2 — what's needed]
```

### Step 5 — Update state

After any action is completed, update active.md:
- Advance the stage for that article
- Note any AF criteria now satisfied
- Record any decisions or blockers in notes.md
- Check off completed topics in plan.md

---

## Stage Advancement Logic

Use this to know what comes next for each article:

```
QUEUE → cannibalization check → GREEN/YELLOW → RESEARCH
RESEARCH → anchor locked (AF-01, AF-02 unblocked) → REVIEW
REVIEW → Phase A approved → OUTLINE
OUTLINE → Phase B approved → WRITE
WRITE → Phase C complete → CRITIC GATE (Phase C.5)
CRITIC GATE APPROVED → FAQ
FAQ → all questions 60+ → PUBLISH
PUBLISH → CMS package complete + pasted → DONE
```

If an article is BLOCKED at any stage, note the reason in active.md and move to the next
available article rather than waiting. Return to the blocked article when the blocker is resolved.

---

## Batch Patterns (Use These Daily)

**Morning batch (do this first, before writing anything):**
1. Queue all 6 topics — run cannibalization check on all at once
2. Run SERP Explorer on all GREEN topics — get anchor candidates for all
3. Lock anchors — review and approve all before writing starts
4. This takes ~60 minutes and unblocks the entire day

**Writing batch (then do this):**
1. Run Phase A → B → C → C.5 → D sequentially per article
2. Do not interleave articles during writing — finish one article to PUBLISH before starting the next
3. One article at a time in the writing phase prevents context bleed

**End-of-session (before stopping):**
1. Update active.md with current stage for each article
2. Note any AF failures in notes.md
3. Update GOALS.md iteration log if 5+ articles published
4. Flag any open questions for Luke in notes.md

---

## Shortcut Detection (Built-In)

At every /next run, check for these content shortcuts. If found, flag them:

| Shortcut | Signal | Action |
|----------|--------|--------|
| No anchor locked before writing | Article is in WRITE stage but AF-01 is empty | Stop. Go back to RESEARCH. |
| Generic thought-leadership | AF-02 note reads "important to consider..." | Stop. Find a real practitioner insight. |
| FAQ padded to hit 7 | More than 7 FAQs with no commercial angle | Trim. Quality over quantity. |
| Placeholder URLs in draft | Any [bracket] links in the article | Do not advance to PUBLISH. Fix first. |
| Skipped Critic Gate | Article moved from WRITE to PUBLISH with no C.5 record | Run C.5 immediately. |

---

## /next Output Template (Copy This Every Run)

```
## /next — [date] [time]

### State summary
Articles in-flight: [N]
Done today: [N]
Blocked: [N]

### AF status across in-flight articles
[status table]

### Recommended next action
[action + why + time estimate + AF unlocked]

### After that
[sequence for the next 2-3 actions]

### Blockers
[list or "None"]

### Shortcuts detected
[list or "None detected"]
```
