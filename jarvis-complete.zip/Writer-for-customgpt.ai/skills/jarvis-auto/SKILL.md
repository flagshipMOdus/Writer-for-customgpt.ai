---
name: jarvis-auto
description: >
  Full end-to-end CustomGPT article production from a single topic input. No manual prompting
  between stages. Give it a topic, it runs SERP research, locks anchors, writes the full article,
  self-critiques, and delivers the complete CMS package (article body, FAQ, Rank Math pack, TL;DR,
  URL box) in one output. Use this skill when the user says "write an article about X", "run
  Jarvis on X", "full article X", "auto-run X", or gives a topic and wants the complete output
  without managing each phase manually. This is the production-speed skill — one prompt in,
  publish-ready article out.
---

# Jarvis Auto — Full Article Runner

One topic in. CMS-ready package out.

---

## The 5 Approval Gates

Every gate is a hard stop. You output the gate block and wait. You do not proceed until
the user sends the exact unlock phrase for that gate. Combining gates is a critical failure.

| Gate | Unlocks | Exact phrase to proceed |
|------|---------|------------------------|
| GATE 1 — Anchor + H1 | Writing the outline | approved - write outline |
| GATE 2 — Outline | Writing the article | approved - write the content |
| GATE 3 — Article draft | Running the critic | approved - run critic |
| GATE 4 — Critic report | Writing the FAQ | approved - write faq |
| GATE 5 — FAQ | Delivering publish package | approved - publish |

CRITICAL RULE: Each phrase unlocks EXACTLY ONE next stage.
If the user sends "approved" without the rest of the phrase, reply:
"To proceed to [next stage], reply with the exact phrase: [exact phrase]"
Do not guess intent. Do not proceed.

NEVER combine two gates in one response. One gate per message. Then stop.

---

## On First Response — Print Gate Reference

At the very start of your first response, before anything else, print:

════════════════════════════════
JARVIS GATE REFERENCE
════════════════════════════════
Gate 1 unlock: approved - write outline
Gate 2 unlock: approved - write the content
Gate 3 unlock: approved - run critic
Gate 4 unlock: approved - write faq
Gate 5 unlock: approved - publish
════════════════════════════════

---

## Fixed Defaults (Never Ask, Always Apply)

Persona: Operations manager or IT lead, 50-500 person company, evaluating AI tools for
customer support or internal knowledge management. Desktop. Intermediate expertise. Close to
a buying decision.

### Style Constraints (zero tolerance — all violations are blockers)

- NO bold text anywhere in article body (Rank Math pack exempt)
- NO em dashes (—) anywhere in article body. This means zero. Not one. Search every
  sentence before submitting. The character is — and it must not appear once.
  Use a comma, period, or rewrite the sentence instead.
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words (default ~20)
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion",
  "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

CTA: https://app.customgpt.ai/register/
Language: English
Client: CustomGPT.ai

---

## Stage 1 — SERP Research + Statistical Hook Research (silent)

Do three things silently:

**A. SERP floor mapping**
Search the topic. Map what every top result already covers. Find what they all miss.

Source priority:
1. CustomGPT official docs: docs.customgpt.ai
2. CustomGPT pricing and limits: customgpt.ai/pricing, customgpt.ai/customgpt-limits-explained
3. CustomGPT case studies and blog
4. G2 / Capterra verified user reviews
5. Competitor official pricing and docs

**B. Statistical hook research**
Search for 3-5 published statistics that support the article's thought-leadership angle.
These must be:
- From a named, credible source (Gartner, Forrester, IDC, McKinsey, G2, Salesforce State
  of Service, Zendesk CX Trends, etc.)
- Quantified with a number (percentage, dollar figure, time saved, etc.)
- Relevant to why the buyer's decision matters — not generic AI trend stats

Good examples:
- "Gartner predicts that by 2027, chatbots will become the primary customer service
  channel for roughly 25% of organizations."
- "Salesforce State of Service: 83% of service decision-makers say AI is transforming
  how customers interact with support."
- "Zendesk CX Trends 2024: teams using AI resolve tickets 34% faster on average."

Bad examples (too generic, add nothing to comparison):
- "AI is growing rapidly"
- "More companies are adopting AI"

If a DATA_POINT was provided in input, treat as pre-verified AF-01. Still run stat research.

**C. Anchor confirmation**
AF-01: specific number, limit, mechanic, or verified fact absent from SERP floor.
AF-02: genuine practitioner reframe — the wrong question most buyers are asking,
and what the decision actually hinges on.

If no AF-01 exists: STOP. "No verifiable data point found. Suggested reframe: [angle].
Reply with a data point or confirm reframe."

---

## GATE 1 — Anchor + H1 + Stat Candidates

After research, output ONLY this block. Then stop.

════════════════════════════════
GATE 1 — Anchor + H1 Review
════════════════════════════════

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

STATISTICAL HOOKS (3-5 candidates for use in article body):
1. "[Stat]" — Source: [Publisher, report name, year] — Supports: [which section/angle]
2. "[Stat]" — Source: [Publisher, report name, year] — Supports: [which section/angle]
3. "[Stat]" — Source: [Publisher, report name, year] — Supports: [which section/angle]
[add more if found]
Note: These will be woven into body copy where they strengthen the argument — not
listed as a data dump.

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare | Solve | Learn | Navigate

════════════════════════════════
To proceed: approved - write outline
To change H1: CHANGE H1: [your title]
To change anchor: CHANGE ANCHOR: [your angle]
════════════════════════════════

---

## Stage 2 — Build Outline

Only runs after: approved - write outline

Rules:
- Mark which H2 carries AF-01 with [ANCHOR]
- Mark which H2 carries AF-02 with [TL]
- Mark which section will use a statistical hook with [STAT]
- Include one section for the buyer journey CTA bridge (see CTA rules below)
- Confirm list-section quota
- Include FAQ placeholder and Conclusion placeholder
- Build evidence list (5-10 sources: Publisher | URL | Type | Date | What it supports)
  — must include at least 2 docs.customgpt.ai links
- All H2/H3: 2-6 words, no brackets, no detail in heading

---

## GATE 2 — Outline Review

After building outline, output ONLY this block. Then stop.

════════════════════════════════
GATE 2 — Outline Review
════════════════════════════════

H1: [title]
Short Answer: [1-2 sentences, max 50 words]

[Full H2/H3 structure — mark [ANCHOR], [TL], [STAT] sections]

H2: FAQ
H2: Conclusion
H2: Facts and Sources

List-section quota: [N H2s, max N allowed, using N]
Anchor placement: [section name]
Thought-leadership placement: [section name]
Stat hook placement: [section name(s)]
CTA bridge placement: [section name]
docs.customgpt.ai links planned: [list URLs]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
To proceed: approved - write the content
To change structure: CHANGE: [your feedback]
════════════════════════════════

---

## Stage 3 — Write Article

Only runs after: approved - write the content

### Writing Requirements (all mandatory)

1. Short Answer paragraph first (max 50 words)

2. Follow approved outline exactly — no added or removed H2s

3. Every H2 section uses one of two templates:
   - Action/steps: context paragraph (15-40w) + 5-8 steps + success-check paragraph
   - Explanatory: What paragraph + Why paragraph + How paragraph (each 15-40w)

4. All paragraphs 15-40 words. Default ~20. Count before submitting.

5. NO EM DASHES (—). Before submitting, do a final scan of every sentence.
   Replace any — with: a comma, a period and new sentence, or a rewrite.
   This rule has no exceptions and no tolerance.

6. Exactly one example section (real named scenario, not generic)

7. AF-01 data-point in body text, not just metadata

8. AF-02 thought-leadership reads as a genuine practitioner voice

9. At least 2 statistical hooks woven into body copy where they strengthen the
   argument naturally. Each must be attributed inline: "According to [Source], [stat]."
   Do not cluster stats. Place them in the sections where they serve the argument.

10. Internal links: include at least 2 contextual links to docs.customgpt.ai pages
    that are genuinely relevant to what that paragraph discusses. These are real links
    that help a reader understand the product. They go in the body as natural prose
    references, not in a link list.
    Example: "CustomGPT's query counting model is explained in detail at
    docs.customgpt.ai/limits" — only use this if that page actually covers that topic.
    Verify URLs before including.

11. CTA bridge (not just a registration link):
    The Conclusion must contain a buyer journey bridge — 2-3 sentences that:
    - Acknowledge where the reader likely is (evaluating, comparing, not ready to commit)
    - Offer a specific next step matched to their stage:
      * Evaluating: "Start a free 7-day trial — no credit card required"
      * Comparing enterprise: "Book a 30-minute demo with the CustomGPT team"
      * Want to see it live: "See a live demo at customgpt.ai/demo"
    - Then the CTA link: https://app.customgpt.ai/register/
    Never just drop the URL bare. Always give the reader a reason to click that matches
    where they are in the buying process.

12. Facts and sources section: 3-7 bullets, each with Publisher + URL + Date

After writing, output ONLY Gate 3. Do not run the critic automatically.

---

## GATE 3 — Article Draft Review

Output the full article body, then ONLY this block. Then stop.

════════════════════════════════
GATE 3 — Article Draft Complete
════════════════════════════════
Word count: [N]
H2 sections: [N]
List-sections used: [N of N allowed]
Em dashes found: ZERO | [locations — if any found, fix before outputting]
AF-01 in body: YES — [section name]
AF-02 in body: YES — [section name]
Stats used: [N] — [source names]
docs.customgpt.ai links: [N] — [URLs used]
CTA bridge: YES — [which stage it targets]

════════════════════════════════
To run critic gate: approved - run critic
To request changes: describe what to fix
════════════════════════════════

---

## Stage 4 — Critic Gate

Only runs after: approved - run critic

Show the full audit trail. Every item must show explicit evidence.

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE C1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Stats present: YES/NO — [quote each stat + source]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL — [fix applied if FAIL]

GATE C2 — Style Compliance

EM DASH SCAN (mandatory — quote every sentence in article that contains —):
Result: ZERO FOUND | [quoted sentences with em dashes]
If any found: [FIX APPLIED — rewrite of each sentence shown]

Bold in body: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [heading]
Banned words: delve / tapestry / pivotal / it's worth noting / in conclusion /
  dive into / game-changer / revolutionize / cutting-edge / seamlessly
  Found: NONE | [word + location]
Paragraph overlength (>40 words): NONE FOUND | [location + count]
Heading overlength (>6 words): NONE FOUND | [heading + count]
List quota: [N used of N allowed]
Status: PASS | FAIL — [fix applied if FAIL]

GATE C3 — Evidence + Links
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
docs.customgpt.ai links present: YES ([N links]) | NO — [fix required]
CTA bridge present: YES — [quote the bridge sentences] | NO — [fix required]
CTA is buyer-journey-aware: YES — [which stage it targets] | NO — [fix required]
Status: PASS | FAIL — [fix applied if FAIL]

GATE C4 — FAQ intent: PENDING

GATE C5 — Anchor Visibility
AF-01 location: [section + position: early/mid/late]
AF-02 location: [section + position: early/mid/late]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL — [fix applied if FAIL]

Pre-FAQ verdict: APPROVED TO PROCEED | BLOCKED
════════════════════════════════

If any gate FAILS: fix inline, mark [FIX APPLIED], re-run only that gate.
Only output Gate 4 if Pre-FAQ verdict = APPROVED TO PROCEED.

---

## GATE 4 — Critic Report Review

Output Critic Gate audit trail, then ONLY this block. Then stop.

════════════════════════════════
GATE 4 — Critic Complete
════════════════════════════════
Gates passed: [list]
Gates fixed: [list fixes, or NONE]
Em dashes: ZERO CONFIRMED
Article status: CLEAN | FIXED ([N] issues resolved)

════════════════════════════════
To write FAQ: approved - write faq
To request further changes: describe what to fix
════════════════════════════════

---

## Stage 5 — FAQ Block

Only runs after: approved - write faq

Write 5-7 FAQ questions for the CMS droppable section.

Each question must:
- Address what a buyer asks the night before signing up — not a beginner question
- Contain at least one specific number, condition, or named constraint in the answer
- Be under 50 words per answer
- Score 60+ on rubric
- Contain zero banned words
- Contain zero em dashes

Scoring rubric:
- Commercial intent (30%): Buyer asks this close to a purchase decision?
- Information gain (25%): Answer adds something not on the SERP?
- Specificity (25%): Contains a number, condition, or named constraint?
- Schema-ready (20%): Under 50 words, plain language, direct answer?

If any question scores below 60: rewrite inline, then re-score.

Run Gate C4 immediately after writing:
Gate C4 — FAQ intent:
Q1: [score] — PASS/FAIL
[etc.]
Lowest scorer: Q[N] at [score]
Gate C4 Status: PASS | FAIL

Then output ONLY Gate 5. Do not deliver publish package.

---

## GATE 5 — FAQ Review

Output FAQ block and Gate C4 results, then ONLY this block. Then stop.

════════════════════════════════
GATE 5 — FAQ Complete
════════════════════════════════
Questions written: [N]
All scored 60+: YES | NO (rewrites: [N])
Gate C4: PASS | FAIL

════════════════════════════════
To deliver publish package: approved - publish
To revise FAQ: describe which questions to change
════════════════════════════════

---

## Stage 6 — Publish Package

Only runs after: approved - publish

The publish package contains ONLY what the CMS operator needs to paste.
No article body. No scoring notes. No audit trails. Clean, paste-ready output only.

Output these four sections and nothing else:

---

════════════════════════════════
RANK MATH PACK
════════════════════════════════
Focus Keyword: [keyword]
SEO Title: [50-60 chars — keyword at start]
Meta Description: [120-160 chars — contains keyword, no em dashes]
Slug: [from Gate 1]
Estimated Score: [/100]
Char counts: Title=[N] | Meta=[N]

════════════════════════════════
TL;DR ([word count] words)
════════════════════════════════
[1 paragraph, 2-3 sentences, outcome-first, no em dashes]
[3-5 bullets — specific, no filler, no em dashes]

════════════════════════════════
FAQ CSS DROPDOWN BLOCK
════════════════════════════════
[Ready to paste into CMS. Uses standard accordion/details HTML pattern.
Copy this entire block into the FAQ section of the post.]

<div class="faq-block">

<details>
<summary>[Question 1 text]</summary>
<p>[Answer 1 text — under 50 words, no em dashes]</p>
</details>

<details>
<summary>[Question 2 text]</summary>
<p>[Answer 2 text]</p>
</details>

[repeat for all FAQ questions]

</div>

════════════════════════════════
FAQ SCHEMA (JSON-LD)
════════════════════════════════
[Paste into the <head> or a Custom HTML block. Follows Google's FAQPage schema
and current structured data guidelines for AI search eligibility.]

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "[Question 1 — exact same text as FAQ CSS block above]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[Answer 1 — exact same text as FAQ CSS block above, plain text only, no HTML tags]"
      }
    },
    {
      "@type": "Question",
      "name": "[Question 2]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[Answer 2]"
      }
    }
  ]
}
</script>

SCHEMA RULES (applied automatically):
- Question text in schema matches FAQ CSS block exactly — word for word
- Answer text in schema is plain text — no HTML, no markdown, no em dashes
- All quotes inside JSON are escaped with \"
- Valid JSON — no trailing commas
- FAQPage @type at root level, Question @type for each item
- Follows Google Search Central structured data guidelines (2024)
- Follows schema.org/FAQPage spec

════════════════════════════════

NOTE: The full article body is in Gate 3. It is not repeated here.
If you need the article body again, ask and it will be provided separately.

---

## Hard Stops (beyond the 5 gates)

1. No AF-01 anchor after research → ask before Gate 1
2. Cannibalization RED → ask to confirm angle before Gate 1
3. Any Critic gate fails twice → surface the problem, ask for guidance

YELLOW cannibalization → continue with differentiation noted in Gate 1.

---

## Em Dash Enforcement Summary

The em dash (—) is the most common style violation. It slips through self-checks because
it is grammatically natural. These are the only acceptable replacements:

Instead of: "The cost is high — especially at scale"
Write: "The cost is high, especially at scale."

Instead of: "Fin charges per resolution — $0.99 each"
Write: "Fin charges per resolution: $0.99 each."

Instead of: "Setup takes an hour — no migration needed"
Write: "Setup takes an hour. No migration needed."

The critic gate EM DASH SCAN quotes every sentence containing — before declaring ZERO FOUND.
This is not optional. If the scan is skipped, the gate has not been run.
