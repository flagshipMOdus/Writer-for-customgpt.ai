---
name: jarvis-production-system
description: >
  Full 7-tab Jarvis article production system for CustomGPT content — covering topic queue,
  cannibalization checks, information gain research, Phase A→D writing, FAQ scoring, and CMS
  publishing pack (Rank Math, TL;DR, URL box). Use this skill whenever the user mentions
  "Jarvis", "article queue", "production system", "5-6 articles", "topic queue", "cannibalization
  check", "CMS pack", "publish tab", or wants to run a complete article workflow from topic to
  final CMS-ready output. Also trigger when user says "run the full workflow", "write for CustomGPT",
  or "information gain anchor". Always use this skill alongside aeo-qa-writer for Phase A→D execution.
---

# Jarvis Production System (v2)

A 7-stage article production pipeline for CustomGPT content. Built to produce 5–6 high-quality,
information-gain articles per day — fully CMS-ready with zero formatting errors.

This skill governs the **system layer** (topic queue → research → review → outline → write → FAQ → publish).
For Phase A→D execution (the actual writing), also read `/mnt/skills/user/aeo-qa-writer/SKILL.md`.

---

## System Overview

```
Stage 1: QUEUE       → intake topic, cannibalization check
Stage 2: RESEARCH    → SERP gap + information gain anchor
Stage 3: REVIEW      → Phase A (H1, JTBD, intent, slug)
Stage 4: OUTLINE     → Phase B (H2/H3 structure, evidence)
Stage 5: WRITE       → Phase C (full article draft)
Stage 6: FAQ         → Graded FAQ block (separate from article)
Stage 7: PUBLISH     → Rank Math + TL;DR + URL box
```

Each stage has a clear input, output, and approval gate. Nothing advances until approved.

---

## Locked Style Constraints (Apply to Every Article)

These are always-on. Never ask the user to toggle them:

- **No bold text** in article body
- **No em dashes**
- **No nested bullet lists**
- **No brackets or parentheses in headings**
- H2/H3 max 6 words
- Paragraphs 15–40 words (default ~20)
- List quota: max 1 list section per 6 H2s
- Banned words: delve, tapestry, pivotal, it's worth noting, in conclusion, dive into
- No placeholder URLs — all links must be verified before delivery

---

## Stage 1 — QUEUE

**Purpose:** Accept a topic, check it against published URLs for cannibalization risk.

**Input:** Topic keyword or article idea

**Process:**
1. Compare topic against the 224 published CustomGPT URLs (loaded from session or pasted list)
2. Classify risk: **GREEN** (no overlap), **YELLOW** (partial overlap — can differentiate), **RED** (duplicate — skip or reframe)
3. If YELLOW: suggest a differentiating angle before proceeding
4. If GREEN: mark "Ready for Research"

**Output format:**
```
Topic: [topic]
Status: GREEN | YELLOW | RED
Overlap risk: [None | Partial match with: URL] 
Recommended action: [Research → | Reframe as: X | Skip]
```

**Queue management:** Track up to 10 topics in order. Show status column for each.

---

## Stage 2 — RESEARCH

**Purpose:** Find the information gain anchor — the one insight the top SERP results don't have.

**This is the most important stage. No article should proceed without an anchor.**

**Input:** Approved topic from Queue

**Process:**
1. Identify the likely top 3–5 SERP results for this topic (use web search if available)
2. Identify what they all cover (the "covered ground")
3. Identify what's missing: specific data, limitations, version-specific details, real-world results, pricing edge cases, compliance specifics, integration constraints
4. Select ONE best anchor — the sharpest, most specific insight a qualified buyer would value

**Output format:**
```
## Research: [Topic]

**What the top results cover:**
- [point 1]
- [point 2]
- [point 3]

**What's missing (gap candidates):**
1. [gap 1] — specificity level: high | medium
2. [gap 2] — specificity level: high | medium
3. [gap 3] — specificity level: high | medium

**Recommended anchor:**
[One clear, specific information gain statement]
Source/evidence: [where this comes from]

**Anchor approved?** → Type ANCHOR_APPROVED to proceed to Review
```

**Information gain types (ranked best to worst):**
1. Specific number/limit from CustomGPT docs (e.g., "max 400 pages per source")
2. Real-world result with metric (e.g., "58% reduction in setup time")
3. Limitation or constraint competitors don't mention
4. Version-specific or integration-specific detail
5. Compliance or legal nuance (GDPR %, specific regulation)
6. Comparison data point (specific vs. generic)

---

## Stage 3 — REVIEW (Phase A)

**Purpose:** Lock the H1, JTBD, intent classification, and slug before any writing.

**Input:** Anchor from Research stage

**Run Phase A** from the aeo-qa-writer skill with anchor embedded:
- Tell Claude: "My information gain anchor is [X]. Treat this as the spine of the article."
- Produce: H1, JTBD, intent (Solve/Learn/Compare/Navigate), slug, near-tie alternatives

**Approval gate:** User confirms or adjusts H1 before outline is built.

**Output format:** Follow Phase A format from aeo-qa-writer SKILL.md exactly.

---

## Stage 4 — OUTLINE (Phase B)

**Purpose:** Full H2/H3 structure with evidence sourcing.

**Run Phase B** from aeo-qa-writer skill.

Additional requirements for this system:
- Anchor must appear explicitly in at least one H2 section
- Evidence list must include at least one CustomGPT-specific source (docs, product page, or case study)
- FAQ section placeholder must be in outline (will be built separately in Stage 6)
- List quota confirmed before approval

**Approval gate:** User confirms or edits outline before writing begins.

---

## Stage 5 — WRITE (Phase C)

**Purpose:** Full article draft — body only. No FAQ mixed in.

**Run Phase C** from aeo-qa-writer skill with all locked style constraints active.

CMS formatting rules (always apply):
- No bold in body
- No em dashes
- H2/H3 headings only (no H4+)
- External links: open in new tab (note for CMS paste)
- TL;DR and FAQ are separate outputs — do NOT include in article body

**Output:** Clean article body from H1 through Conclusion. Article Metadata (Rank Math pack) at end.

---

## Stage 6 — FAQ

**Purpose:** Graded FAQ block built separately for the CMS droppable section.

**Format:** 5–7 questions. Each question graded against 4 criteria:

| Criterion | Weight | What it means |
|-----------|--------|---------------|
| Commercial intent | 30% | Would a buyer ask this the night before signing up? |
| Information gain | 25% | Does the answer contain something competitors don't say? |
| Specificity | 25% | Exact numbers, steps, or conditions — not generic |
| Schema-ready | 20% | Under 50 words, no AI tells, plain direct answer |

**Scoring:** Each FAQ scored 0–100. Flag any below 60 for rewrite.

**Banned in FAQ answers:** delve, tapestry, pivotal, "it's worth noting", "great question", nested lists, hedging phrases

**Output format:**
```
## FAQ

**Q: [Question]**
A: [Answer — under 50 words, direct, specific]
Score: [0–100] | Weakest criterion: [criterion]

[repeat for each question]

**Lowest scorer:** Q[X] — suggested rewrite: [rewrite]
```

---

## Stage 7 — PUBLISH

**Purpose:** Full CMS package ready to paste. Zero manual work after this stage.

**Outputs in order:**

### 7A: Rank Math Pack (top of publish output)
```
Focus Keyword: [...]
SEO Title: [...] (50–60 chars, keyword at start)
Meta Description: [...] (120–160 chars, contains keyword)
Slug: [from Phase A]
Estimated Rank Math Score: [0–100]
```

### 7B: Rank Math Audit
Checklist with passes/fails and exact fix wording for anything that fails.

### 7C: TL;DR (45–75 words)
1 short paragraph (2–3 sentences) + 3–5 bullets.
Rules: outcome-first, who it's for, one decision trigger, one watch-out, practical next step.

### 7D: URL Box
2-column table. Anchor text must be exact phrase from draft. Mix internal + external.

### 7E: Download marker
Note: "Article ready. Copy body → CMS. Copy FAQ → droppable FAQ section. Rank Math pack → SEO tab."

---

## Daily Workflow (5–6 Articles)

**Morning (15 min):**
Queue 6 topics → run cannibalization check → mark status for each

**Research pass (60 min):**
Research anchors for all GREEN topics in one pass — batch the SERP gap work

**Writing pass (per article ~30 min):**
Review → Outline → Write → FAQ → Publish → paste into CMS

**Quality gate (never skip):**
Before marking any article done, confirm:
- [ ] Information gain anchor appears in article
- [ ] No bold text in body
- [ ] No em dashes
- [ ] FAQ scored — no question below 60
- [ ] All URLs verified (no placeholders)
- [ ] TL;DR 45–75 words
- [ ] Rank Math pack complete

---

## Commands Reference

| Command | Action |
|---------|--------|
| `QUEUE: [topic]` | Add topic to queue, run cannibalization check |
| `RESEARCH: [topic]` | Run SERP gap analysis, output anchor candidates |
| `ANCHOR_APPROVED` | Proceed to Phase A (Review) |
| `APPROVE_REVIEW` | Proceed to Phase B (Outline) |
| `APPROVE_OUTLINE` | Proceed to Phase C (Write) |
| `WRITE_FAQ` | Generate graded FAQ block |
| `PUBLISH` | Generate full CMS package |
| `SKIP_PHASE_D` | Skip post-draft packages (not recommended) |

---

## CustomGPT Persona (Default)

Unless user specifies otherwise, write for:
- **Role:** Operations manager or IT lead at a mid-market company
- **Device:** Desktop
- **Expertise:** Intermediate (knows what AI chatbots are, evaluating vendors)
- **Intent:** Comparing options, close to a buying decision
- **Region:** US/Global, compliance awareness varies
- **Tone expectation:** Expert, neutral, practical — no hype

---

## Cannibalization Guard

Always load the list of published URLs at session start. When user pastes or uploads the sheet,
extract all URLs from the "URL" or "Published URL" column and store as the reference list.

Compare new topics against this list by:
1. Checking keyword overlap in the URL slug
2. Checking title/topic semantic similarity
3. If overlap found: surface the existing URL and ask user to differentiate or skip
