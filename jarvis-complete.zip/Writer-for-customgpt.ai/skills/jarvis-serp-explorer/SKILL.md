---
name: jarvis-serp-explorer
description: >
  Fast SERP gap analysis agent for CustomGPT content — scans what the top search results already
  cover for a given topic and surfaces the information gain anchor (data-point and thought-leadership
  angle) before any writing begins. Use this skill when the user says "explore this topic", "find
  my anchor", "SERP gap", "what's missing from the top results", "research phase", "run the explorer",
  "batch research", or provides a list of topics to research before writing. Always use before
  Phase A of the aeo-qa-writer workflow. Run this on all topics in the morning batch before any
  writing begins. This is the fastest way to unblock AF-01 and AF-02 simultaneously.
---

# Jarvis SERP Explorer

Fast, focused SERP gap analysis. Time budget: 3 to 5 minutes per topic.
The goal is not comprehensive research — it is finding the ONE anchor that makes the article
worth writing. Stop when you have it. Do not over-explore.

This agent satisfies AF-01 (data-point gain) and AF-02 (thought-leadership gain) from GOALS.md.
Nothing else should be written until both are locked.

---

## Operating Principles

- Speed over completeness. 3 to 5 minutes per topic, not 30.
- One strong anchor beats five weak ones. Pick the best and move on.
- If no anchor exists for this topic, say so immediately. Do not invent one.
- Batch all topics before writing any of them.
- The anchor is a contract: once locked, the article is built around it. Not the other way around.

---

## Inputs

- Topic or keyword (from the Jarvis queue)
- Optionally: any CustomGPT docs page, case study, or known product detail relevant to the topic

---

## Process (3 to 5 minutes per topic)

### Step 1 — Map the coverage floor (60 seconds)

Identify what the top 3 to 5 SERP results almost certainly cover for this topic. This is the
"floor" — the minimum a qualified reader already knows. Do not write content that only covers this.

Common floor content for CustomGPT topics:
- What the feature/integration is
- Basic setup steps
- General benefits of AI chatbots
- High-level pricing categories
- Generic "is it right for your business?" framing

### Step 2 — Identify gaps (90 seconds)

Look for what the floor does NOT include. Use these gap categories as prompts:

| Gap category | What to look for |
|---|---|
| Product limits | Specific caps, quotas, maximums, minimums |
| Version / plan differences | Features that are enterprise-only or plan-specific |
| Integration constraints | Permission levels, API versions, known failure modes |
| Real-world performance | Timing, accuracy %, reduction in X across N cases |
| Compliance specifics | Named regulation, specific clause, certification status |
| Pricing edge cases | Overage triggers, billing model nuances |
| Failure modes | What breaks, when, and why |
| Comparison differentiators | One specific thing CustomGPT does differently from named competitors |
| Practitioner reframe | A way of thinking about the topic that flips the usual evaluation lens |

### Step 3 — Score gap candidates (60 seconds)

Rate each gap on three dimensions, 1 to 5:

- Specificity: does it contain a number, condition, or named constraint?
- Buyer relevance: would someone about to purchase care about this?
- Verifiability: can it be traced to CustomGPT docs, a case study, or an official source?

Select the highest-scoring gap as the data-point anchor (AF-01).

### Step 4 — Surface the thought-leadership angle (60 seconds)

Ask: what would a senior practitioner — someone who has deployed AI chatbots at scale — say
about this topic that goes beyond what's on the SERP?

Prompts to find the angle:
- What's the most common mistake buyers make when evaluating this?
- What does the price look like at the surface vs. at scale?
- What breaks that nobody talks about?
- What's the real question buyers should be asking but aren't?
- What assumption does everyone make that is actually wrong?

This does not need to come from a source. It is a genuine insight. It must be specific enough
that a practitioner would nod and say "yes, that's true" — not vague enough that anyone could say it.

### Step 5 — Verify the data-point anchor (30 seconds)

Before locking: confirm the data-point anchor is traceable.
- If it comes from CustomGPT docs: note the URL
- If it comes from a case study: note the source
- If it is inferred or estimated: mark it as "inferred — hedge in article"
- If it cannot be verified at all: downgrade it and find another

---

## Output Format (Per Topic)

```
## SERP Explorer: [Topic]

### Coverage floor (what top results all say)
- [point 1]
- [point 2]
- [point 3]

### Gap candidates
| Gap | Specificity /5 | Buyer relevance /5 | Verifiable | Total |
|-----|---------------|-------------------|------------|-------|
| [gap 1] | [X] | [X] | Y/N | [X] |
| [gap 2] | [X] | [X] | Y/N | [X] |
| [gap 3] | [X] | [X] | Y/N | [X] |

### Locked anchor

Data-point (AF-01):
[One clear sentence — specific, verifiable]
Source: [URL or "inferred"]
Confidence: High / Medium / Low

Thought-leadership (AF-02):
[One clear sentence — genuine practitioner insight, not a summary]
Why it's non-obvious: [One sentence explaining what makes this a real insight vs. generic advice]

### How to use in Phase A
Tell Claude: "My information gain anchor is: [data-point]. My thought-leadership angle is:
[insight]. Build the article around proving and expanding both."

### Status
AF-01: LOCKED | WEAK | NOT FOUND
AF-02: LOCKED | WEAK | NOT FOUND
Ready for Phase A: YES | NO (reason: [reason])
```

---

## Batch Mode (Morning Research Pass)

When researching multiple topics before the day's writing begins:

1. List all topics from today's plan.md
2. Run Steps 1 to 4 for each topic in sequence — do not start writing between topics
3. Output all anchors in one block
4. User reviews: approve each anchor, request an alternative, or mark the topic as "needs stronger anchor before writing"
5. Lock all approved anchors, update active.md, then begin writing sequentially

Batch output format:

```
## Morning Anchor Batch — [date]

Topic 1: [topic]
AF-01: [anchor] | AF-02: [insight] | Status: LOCKED / WEAK / NOT FOUND

Topic 2: [topic]
AF-01: [anchor] | AF-02: [insight] | Status: LOCKED / WEAK / NOT FOUND

[repeat]

Summary:
- Ready to write: [N topics]
- Needs stronger anchor: [N topics — list them]
- No anchor found (requeue or reframe): [N topics — list them]
```

---

## When No Anchor Exists

If no strong gap can be found for a topic:

1. **Narrow the topic first.** "CustomGPT integrations" → "CustomGPT Salesforce connector: what enterprise admins need to know"
2. **Go to CustomGPT docs directly.** Any specific number, limit, or plan difference counts.
3. **Check if the topic is worth writing at all.** If a strong anchor doesn't exist and can't be constructed, the article will not pass AF-01. Flag it and move to the next topic.
4. **Never fabricate an anchor.** A weak anchor found honestly is better than a strong one invented. A fabricated anchor will fail evidence integrity (AF-06) and damage the site.

Output when no anchor found:
```
Topic: [topic]
Status: NO ANCHOR FOUND
Reason: [Why — e.g. "Topic is too generic, existing SERP results cover all angles adequately"]
Recommended action: REFRAME as [narrower angle] | REQUEUE | SKIP
```

---

## CustomGPT-Specific Research Shortcuts

These sources are the fastest places to find real data points for CustomGPT topics:

- CustomGPT docs (app.customgpt.ai/docs or equivalent) — limits, plan features, integrations
- CustomGPT case studies — real metrics, customer types, use case specifics
- CustomGPT changelog / release notes — version-specific details, new features, removed features
- Semrush (marketing@customgpt.ai credentials) — keyword volume, SERP composition, competitor presence
- G2 / Capterra reviews — real user pain points, actual failure modes, honest comparisons
- CustomGPT's own pricing page — plan-specific constraints, enterprise flags

If browsing is available: fetch one of these sources per topic during Step 2.
If not: use what's known from prior sessions and mark confidence level accordingly.
