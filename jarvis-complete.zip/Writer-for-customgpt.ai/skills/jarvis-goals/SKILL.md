---
name: jarvis-goals
description: >
  Project-level definition of done for CustomGPT content production. Contains the 8 acceptance
  criteria (AF-01 through AF-08) that every article must satisfy before publishing, the North
  Star objective, constraints, and Luke's exact quality bar in his own words. Use this skill when
  checking whether an article is ready to publish, when assessing overall article quality, when
  the user says "does this pass", "check against goals", "is this publishable", or whenever a
  quality decision needs to be grounded in the project standard. Also read this at the start of
  every /next session and before running the content-critic. This is the single source of truth
  — if a criterion isn't in here, it isn't a requirement.
---

# Jarvis GOALS — CustomGPT Content Project

This skill contains the project-level acceptance criteria. Read GOALS.md (bundled in this skill)
for the full specification.

## Quick Reference — The 8 AF Criteria

| AF | Criterion | Threshold |
|----|-----------|-----------|
| AF-01 | Data-point gain | 1 verified specific fact minimum |
| AF-02 | Thought-leadership gain | 1 genuine practitioner insight minimum |
| AF-03 | Conversion focus | Written for a buyer near decision, not a learner |
| AF-04 | FAQ commercial intent | All FAQs score 60+, minimum 5 max 7 |
| AF-05 | Style compliance | Zero violations — no bold, no em dashes, no nested lists |
| AF-06 | Evidence integrity | All URLs real, all claims traceable |
| AF-07 | CMS readiness | Rank Math pack + TL;DR + FAQ block + URL box all present |
| AF-08 | Cannibalization check | No substantial overlap with 224 published URLs |

PUBLISH = all 8 SATISFIED
BLOCKED = any NOT SATISFIED

## Luke's Quality Bar (His Exact Words)

"Highly accurate, provide information gain — means you add some new data, info, perspective
that isn't present on the internet already, especially in that form."

"Thought-leadership — providing a unique and valuable perspective, new thoughts that a human
practitioner can only give."

"A high-quality, highly-compelling article that would convert a cynical but qualified buyer
if they landed on the page."

## Full Specification

Read GOALS.md in this skill package for complete AF definitions, examples of PASS/FAIL,
constraints, and the iteration log.
