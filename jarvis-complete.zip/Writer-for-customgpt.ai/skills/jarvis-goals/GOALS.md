# CustomGPT Content Project — GOALS.md

**Project:** CustomGPT blog content production
**Owner:** Mo (writer) / Luke Marchand (client)
**Last updated:** 2026-03
**Status:** Trial week active

This is the single source of truth for what a passing article looks like.
Every skill, every quality gate, every `/next` decision references this file.
If it's not in here, it's not a requirement.

---

## North Star Objective

Publish articles that convert a cynical but qualified buyer — someone who already knows what
CustomGPT is, has looked at competitors, and is skeptical of AI hype — by giving them something
genuinely useful they could not find in 30 seconds of Googling.

Articles should drive trial sign-ups, enterprise inquiries, or qualified engagement.
Articles that don't serve a buyer at or near a purchase decision are out of scope.

---

## Acceptance Criteria (AF)

These are the gates every article must pass before it is published. Each is binary: SATISFIED or NOT SATISFIED.

### AF-01: Information Gain — Data Point
The article contains at least one specific, verifiable data point not readily available on the SERP.

Examples of PASS:
- "CustomGPT limits each source to 400 pages per project"
- "Average response latency is under 300ms on the standard plan"
- "GDPR Article 28 compliance requires a signed DPA — available on request"

Examples of FAIL:
- "CustomGPT is trusted by thousands of businesses"
- "AI chatbots can significantly improve customer satisfaction"
- Any statistic without a traceable source

**Threshold:** 1 verified data point minimum. 2+ is target.

---

### AF-02: Information Gain — Thought Leadership
The article contains at least one genuine practitioner insight: a reframe, a counter-intuitive
truth, a hard-won lesson, or a perspective that goes beyond summarising existing knowledge.

Examples of PASS:
- "Most teams evaluate chatbots on features. The real question is: who owns the knowledge base in 6 months?"
- "Price-per-query looks cheap at low volume. At scale, re-training frequency is the real cost driver."
- A genuine recommendation that names a trade-off ("Choose X when Y, but not if Z")

Examples of FAIL:
- "It's important to consider your business needs when choosing an AI solution"
- "There are many factors to consider"
- Restating what a feature does without adding a practitioner's angle on when or why

**Threshold:** 1 genuine insight minimum. This cannot be AI-generated filler dressed up as insight.

---

### AF-03: Conversion Focus
The article is written for a buyer near a decision — not a curious learner, not an early-stage researcher.

SATISFIED if:
- The H1 addresses a question a buyer would ask, not a beginner
- At least one section directly addresses a buying concern (cost, risk, integration, comparison)
- The conclusion gives a specific, actionable next step tied to CustomGPT

NOT SATISFIED if:
- The article reads like a Wikipedia entry ("CustomGPT is a platform that allows...")
- The article explains the category rather than helping a buyer decide

---

### AF-04: FAQ Commercial Intent
Every FAQ question passes a commercial intent test.

SATISFIED if:
- Each FAQ scores 60+ using the 4-criterion rubric (commercial intent 30%, info gain 25%, specificity 25%, schema-ready 20%)
- No FAQ is a generic explainer question ("What is a chatbot?")
- At least 2 FAQs contain a specific number, condition, or named constraint

NOT SATISFIED if:
- Any FAQ scores below 60
- Any FAQ could appear in a beginner's guide to AI chatbots
- FAQs are padded to hit a quantity target

**Threshold:** All FAQs 60+. Minimum 5, maximum 7.

---

### AF-05: Style Compliance (Zero Violations)
The article contains zero style violations.

Checked items:
- No bold text in article body
- No em dashes
- No nested bullet lists
- No brackets or parentheses in any heading
- No banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- Paragraph length: 15 to 40 words each
- List quota: max 1 list-section per 6 H2s
- H2/H3 headings: 2 to 6 words, no brackets

**Threshold:** Zero violations. One violation = NOT SATISFIED.

---

### AF-06: Evidence Integrity
Every claim is traceable. No placeholder URLs. No hallucinated stats.

SATISFIED if:
- All URLs in the article are real and functional
- All statistics have a named source
- All CustomGPT feature claims link to or reference official docs
- No "studies show..." without a named study

NOT SATISFIED if:
- Any [bracket] placeholder URLs remain
- Any statistic is unattributed
- Any feature claim cannot be traced to CustomGPT docs

---

### AF-07: CMS Readiness
The full publish package is present and correct.

Required elements:
- Rank Math pack: Focus Keyword, SEO Title (50-60 chars), Meta Description (120-160 chars), Slug
- TL;DR: 45 to 75 words, outcome-first, contains one decision trigger
- FAQ block: separate from article body, ready for droppable section
- URL box: verified anchor text matched to exact phrases in draft
- No markdown formatting that will break in CMS paste

**Threshold:** All 5 elements present and correct.

---

### AF-08: Cannibalization Check
The article does not substantially overlap with any of the 224 published CustomGPT URLs.

SATISFIED if:
- Topic and primary keyword are distinct from existing URLs
- If partial overlap exists, the angle is clearly differentiated

NOT SATISFIED if:
- A published article already covers the same keyword with the same intent
- No differentiation angle was identified before writing began

---

## Quality Score (Summary View)

When all 8 AF criteria are assessed, summarise as:

| AF | Criterion | Status |
|----|-----------|--------|
| AF-01 | Data-point gain | SATISFIED / NOT SATISFIED |
| AF-02 | Thought-leadership gain | SATISFIED / NOT SATISFIED |
| AF-03 | Conversion focus | SATISFIED / NOT SATISFIED |
| AF-04 | FAQ commercial intent | SATISFIED / NOT SATISFIED |
| AF-05 | Style compliance | SATISFIED / NOT SATISFIED |
| AF-06 | Evidence integrity | SATISFIED / NOT SATISFIED |
| AF-07 | CMS readiness | SATISFIED / NOT SATISFIED |
| AF-08 | Cannibalization check | SATISFIED / NOT SATISFIED |

**PUBLISH** = All 8 SATISFIED
**BLOCKED** = Any NOT SATISFIED → fix that AF, re-check, then re-assess

---

## Constraints (Non-Negotiable)

- **Velocity target:** 5 to 6 articles per day during trial week. Quality gates apply to all of them.
- **Client CMS:** WordPress with Rank Math. No bold in body. No raw markdown tables.
- **Persona:** Operations manager or IT lead, mid-market, evaluating vendors, close to a decision.
- **Voice:** Expert, neutral, practical. No hype. No filler. No AI tells.
- **Cannibalization pool:** 224 published CustomGPT URLs (maintained in Google Sheet).
- **Semrush access:** marketing@customgpt.ai — use for keyword validation and SERP data.

---

## What Luke Cares About Most (In His Words)

1. "Quality would be the focus."
2. "Highly accurate, provide information gain — means you add some new data, info, perspective
   that isn't present on the internet already, especially in that form."
3. "Thought-leadership — providing a unique and valuable perspective, new thoughts that a human
   practitioner can only give."
4. "Overall is it actually a high-quality, highly-compelling article that would convert a cynical
   but qualified buyer if they landed on the page."
5. "Not 3 a day but no wasted time."

These are the words every article is held against. When in doubt, re-read this section.

---

## Definition of Done (Per Article)

An article is done when:
- [ ] All 8 AF criteria are SATISFIED
- [ ] Critic Gate (Phase C.5) returned APPROVED
- [ ] Full CMS publish package is generated (Phase D)
- [ ] Article is pasted into CMS and formatted correctly
- [ ] Row updated in Google Sheet with URL, status, and date

An article is NOT done when:
- Any AF is NOT SATISFIED, regardless of how much time was spent on it
- The CMS package is incomplete
- The article has not been checked against the cannibalization pool

---

## Iteration Log

Use this section to track what's working and what isn't across articles.
Update after every 5 articles published.

| Date | Articles published | AF failures (most common) | What to change |
|------|-------------------|---------------------------|----------------|
| [date] | [N] | [AF-XX most often] | [adjustment] |
