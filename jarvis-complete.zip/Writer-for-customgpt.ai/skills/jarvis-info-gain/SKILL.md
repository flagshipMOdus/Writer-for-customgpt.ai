---
name: jarvis-info-gain
description: >
  Research layer for the Jarvis production system — surfaces the information gain anchor before
  any article is written. Use this skill when the user says "find my anchor", "information gain
  research", "SERP gap", "what's missing from the top results", "research phase", or asks what
  angle to use for a CustomGPT article. Also trigger when the user wants to know what competitors
  don't cover, or needs a data point to make an article novel. Always use before running Phase A
  of the aeo-qa-writer workflow. This is the single most important quality gate in the system.
---

# Jarvis Information Gain Research

The information gain anchor is the **one thing** that makes an article worth reading for a
qualified buyer who already knows the basics. Without it, the article is a repackage of
existing content — and Google (and human readers) treat it accordingly.

This skill defines how to find, evaluate, and lock the anchor before any writing begins.

---

## What Information Gain Means

Luke's exact words: *"provide information gain — means you add some new data, info, perspective
that isn't present on the internet already, especially in that form."*

Alden's framework grades it at 25% of article quality — and it's what separates content that
gets cited (in ChatGPT, Bing, Perplexity) from content that gets ignored.

**Good anchor:** "CustomGPT limits each source to 400 pages. For large knowledge bases, this
means you need to prioritize documents by buyer stage, not by volume."

**Bad anchor:** "CustomGPT is a powerful AI chatbot builder used by many businesses."

---

## Research Process

### Step 1 — Identify the Topic's Information Landscape

For the given topic, identify:
- The likely search query a buyer would use
- The 3–5 pages most likely to rank for it
- What those pages definitely cover (the "floor" of knowledge)

If web search is available: fetch top results and scan for coverage.
If not: reason from what's commonly known about the topic.

### Step 2 — Map the Gaps

Look for what the top results DON'T say. Common gap types:

| Gap Type | Example |
|----------|---------|
| Specific product limits | "Max file size is 15MB per upload" |
| Version/plan differences | "Enterprise only — not available on trial" |
| Real-world performance data | "Setup time reduced 58% across 1,240 tickets" |
| Compliance specifics | "GDPR requires data residency — EU plan needed" |
| Integration constraints | "Salesforce connector requires admin permissions + API v2.0+" |
| Pricing edge cases | "Overage charges apply after 10,000 queries/month" |
| Failure modes | "Context window limits cause truncation on documents >50 pages" |
| Comparison differentiators | "Unlike Intercom, CustomGPT doesn't charge per seat" |

### Step 3 — Score and Select the Best Anchor

Rate each gap candidate on three dimensions:

**Specificity (1–5):** Does it contain a number, condition, or named constraint?
**Buyer relevance (1–5):** Would someone about to purchase care about this?
**Verifiability (1–5):** Can you point to a source (CustomGPT docs, case study, official page)?

Select the candidate with the highest combined score. If two are tied, prefer the one with
higher buyer relevance.

### Step 4 — Verify the Anchor

Before locking the anchor:
- Confirm it appears in CustomGPT's official docs, a case study, or a verifiable source
- If it's a feature claim: note the URL of the docs page
- If it's a performance stat: note where it came from
- If it can't be verified: mark it as "inferred" and use with appropriate hedging in the article

---

## Output Format

```
## Information Gain Research: [Topic]

### Coverage floor (what top results all say)
- [common point 1]
- [common point 2]
- [common point 3]

### Gap candidates
| # | Gap | Specificity | Buyer relevance | Verifiable | Score |
|---|-----|-------------|-----------------|------------|-------|
| 1 | [gap 1] | /5 | /5 | Y/N | [total] |
| 2 | [gap 2] | /5 | /5 | Y/N | [total] |
| 3 | [gap 3] | /5 | /5 | Y/N | [total] |

### Recommended anchor
**Anchor statement:** [One clear sentence]
**Why it wins:** [One sentence explanation]
**Source:** [URL or "inferred from X"]
**Confidence:** High | Medium | Low

### How to use this anchor
Tell Claude at the start of Phase A: "My information gain anchor is [anchor statement].
Build the article around proving and expanding this."
```

---

## Anchor Types by Article Category

### Integration articles (connect X to Y)
Best anchors: exact permission requirements, API version constraints, known failure conditions,
setup time benchmarks, support tier requirements

### Comparison articles (CustomGPT vs competitor)
Best anchors: specific feature that competitor lacks (or has), pricing structure difference,
data residency difference, integration count difference

### How-to articles (how to do X with CustomGPT)
Best anchors: specific step that's non-obvious, known limitation at a certain scale,
version-specific behavior, time/cost benchmark

### Compliance/governance articles
Best anchors: specific regulation name + percentage, CustomGPT's certification status,
data processing agreement terms, audit log availability

### Use case articles (X industry using CustomGPT)
Best anchors: specific result with metric, named company type, adoption rate, time-to-value stat

---

## When You Can't Find a Strong Anchor

If no high-scoring gap exists for this topic:

1. **Narrow the topic.** "CustomGPT integrations" → "CustomGPT Salesforce integration limits"
2. **Go to CustomGPT docs directly.** Look for any number, limit, or condition on the relevant page.
3. **Use a structural anchor.** If no data exists, the anchor can be a framing that nobody else uses — e.g., "evaluating CustomGPT from a procurement lens" vs. "using CustomGPT".
4. **Flag to user.** If no anchor can be found, do not proceed to writing. Surface the issue and suggest a topic reframe or a different topic from the queue.

**Never proceed to writing without an anchor. Generic articles hurt the site.**

---

## Batch Research (for 5–6 articles/day)

When researching multiple topics in one pass:
1. List all approved topics from the queue
2. For each, spend 3–5 minutes identifying top gap candidates
3. Output all anchors in one block before any writing begins
4. User reviews and approves each anchor, or requests alternatives
5. Lock all anchors, then proceed to writing phase sequentially

This prevents context-switching and keeps the research mindset separate from the writing mindset.
