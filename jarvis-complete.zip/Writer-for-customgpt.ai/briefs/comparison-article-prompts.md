# Comparison Article Prompts — CustomGPT.ai
### Paste each block into a fresh Claude chat. Do not modify.

---

## CHAT 1 — CustomGPT vs Intercom Fin

You are running the Jarvis Auto article production system for CustomGPT.ai.

Follow every instruction below exactly. Do not skip stages. Do not summarise instructions back to me. Just run them.

---

### FIXED DEFAULTS — apply to every article, no exceptions

**Persona:** Operations manager or IT lead, 50-500 person company, evaluating AI tools for customer support or internal knowledge management. Desktop user. Intermediate expertise. Close to a buying decision.

**Style constraints (always on):**
- No bold text in article body (Rank Math pack exempt)
- No em dashes anywhere in body
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words, default ~20
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

**CTA:** https://app.customgpt.ai/register/
**Client:** CustomGPT.ai

---

### STAGE 1 — SERP Research (silent, no output)

Search the topic. Map what every top SERP result already covers (the floor). Find what they all miss (the gap).

Source priority:
1. CustomGPT official docs, pricing, limits pages
2. Intercom Fin official pricing and docs
3. G2 / Capterra verified reviews for both tools
4. Third-party comparisons already published

Identify:
- AF-01 (data-point): a specific number, limit, mechanic, or verified fact absent from the SERP floor. Must be traceable to a named source. Priority candidates: Intercom Fin per-resolution pricing (~$0.99/resolved conversation), Intercom base plan requirements before Fin is accessible, CustomGPT query counting mechanics, overage behavior on both platforms.
- AF-02 (thought-leadership): a genuine practitioner reframe of what the decision actually hinges on. Priority candidate: Intercom Fin only works if you already live in Intercom — it is not a standalone AI agent, it is an AI layer on top of a helpdesk subscription. Buyers who don't use Intercom are paying for platform lock-in, not just AI.

If no strong AF-01 after research: stop and ask.

---

### CHECKPOINT 1 — You must stop here and wait for my reply before writing anything.

Output this block exactly:

════════════════════════════════
CHECKPOINT 1 — Approve before writing
════════════════════════════════

ANCHOR LOCKED

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL or named source]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE H1: [your preferred title]
  CHANGE ANCHOR: [your preferred data point or angle]
════════════════════════════════

---

### CHECKPOINT 2 — After I approve Checkpoint 1, build the outline silently then output this block. Wait for my reply before writing.

════════════════════════════════
CHECKPOINT 2 — Approve outline before writing
════════════════════════════════

OUTLINE

H1: [title]
Short Answer: [max 50 words]

[Full H2/H3 structure — mark [ANCHOR] and [TL] sections]

H2: FAQ
H2: Conclusion
H2: Facts and sources

List-section quota: [N H2s → max N allowed, using N]
Anchor placement: [section]
Thought-leadership placement: [section]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE: [feedback]
════════════════════════════════

---

### STAGE 3 — Write full article after Checkpoint 2 approved

Requirements:
1. Short Answer first (max 50 words)
2. Follow approved outline exactly
3. Every H2: Action/steps OR Explanatory template
4. All paragraphs 15-40 words
5. Exactly one real example section
6. AF-01 in body text, not just metadata
7. AF-02 reads as genuine practitioner voice
8. Facts and sources: 3-7 bullets with Publisher + URL + Date
9. Rank Math SEO pack at end

Immediately run Stage 4 after writing without stopping.

---

### STAGE 4 — Critic Gate (auto-runs, show full audit trail)

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE 1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL

GATE 2 — Style Compliance
Bold in body: NONE FOUND | [location]
Em dashes: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [location]
Banned words: NONE FOUND | [word + location]
Paragraph overlength: NONE FOUND | [location + word count]
Heading overlength: NONE FOUND | [heading + word count]
List quota: [N used of N allowed]
Status: PASS | FAIL

GATE 3 — Evidence Integrity
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
Status: PASS | FAIL

GATE 4 — FAQ intent: PENDING

GATE 5 — Anchor Visibility
AF-01 location: [section + position]
AF-02 location: [section + position]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL

Overall: APPROVED TO PROCEED | BLOCKED

---

### STAGE 5 — FAQ Block (5-7 questions)

Each question: buyer-decision-stage only, one specific number/condition/constraint in answer, under 50 words, zero banned words.

Score each on: Commercial intent (30%) + Info gain (25%) + Specificity (25%) + Schema-ready (20%). Rewrite any below 60 before outputting.

Run Gate 4 on FAQ output.

---

### STAGE 6 — Publish Package

Deliver in labelled sections: RANK MATH PACK / TL;DR / ARTICLE BODY / FAQ BLOCK / URL BOX / AF SCORECARD / VERDICT

AF Scorecard checks: AF-01 through AF-08. VERDICT: PUBLISH or BLOCKED.

---

**TOPIC:** CustomGPT.ai vs Intercom Fin

Begin with Stage 1 now.

---
---
---

## CHAT 2 — CustomGPT vs Zendesk AI

You are running the Jarvis Auto article production system for CustomGPT.ai.

Follow every instruction below exactly. Do not skip stages. Do not summarise instructions back to me. Just run them.

---

### FIXED DEFAULTS — apply to every article, no exceptions

**Persona:** Operations manager or IT lead, 50-500 person company, evaluating AI tools for customer support or internal knowledge management. Desktop user. Intermediate expertise. Close to a buying decision.

**Style constraints (always on):**
- No bold text in article body (Rank Math pack exempt)
- No em dashes anywhere in body
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words, default ~20
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

**CTA:** https://app.customgpt.ai/register/
**Client:** CustomGPT.ai

---

### STAGE 1 — SERP Research (silent, no output)

Search the topic. Map the SERP floor. Find the gap.

Source priority:
1. CustomGPT official docs, pricing, limits pages
2. Zendesk official pricing and AI add-on documentation
3. G2 / Capterra verified reviews for both tools
4. Third-party comparisons already published

Identify:
- AF-01 (data-point): Priority candidate: Zendesk AI features require Suite Professional at minimum ($115/agent/month billed annually). A 5-agent support team pays $575/month in base plan costs before any AI feature is unlocked. CustomGPT Standard is $99/month flat with no per-seat pricing. Verify exact current Zendesk plan requirements.
- AF-02 (thought-leadership): Priority candidate: Zendesk AI is not an AI product — it is an AI feature inside a ticketing system. Buyers evaluating it as an AI chatbot are evaluating the wrong thing. The real question is whether you want your AI to live inside your helpdesk or in front of it.

If no strong AF-01 after research: stop and ask.

---

### CHECKPOINT 1 — You must stop here and wait for my reply before writing anything.

Output this block exactly:

════════════════════════════════
CHECKPOINT 1 — Approve before writing
════════════════════════════════

ANCHOR LOCKED

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL or named source]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE H1: [your preferred title]
  CHANGE ANCHOR: [your preferred data point or angle]
════════════════════════════════

---

### CHECKPOINT 2 — After I approve Checkpoint 1, build outline silently then output this block. Wait for my reply.

════════════════════════════════
CHECKPOINT 2 — Approve outline before writing
════════════════════════════════

OUTLINE

H1: [title]
Short Answer: [max 50 words]

[Full H2/H3 structure — mark [ANCHOR] and [TL] sections]

H2: FAQ
H2: Conclusion
H2: Facts and sources

List-section quota: [N H2s → max N allowed, using N]
Anchor placement: [section]
Thought-leadership placement: [section]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE: [feedback]
════════════════════════════════

---

### STAGE 3 — Write full article after Checkpoint 2 approved

Requirements:
1. Short Answer first (max 50 words)
2. Follow approved outline exactly
3. Every H2: Action/steps OR Explanatory template
4. All paragraphs 15-40 words
5. Exactly one real example section
6. AF-01 in body text, not just metadata
7. AF-02 reads as genuine practitioner voice
8. Facts and sources: 3-7 bullets with Publisher + URL + Date
9. Rank Math SEO pack at end

Immediately run Stage 4 after writing without stopping.

---

### STAGE 4 — Critic Gate (auto-runs, show full audit trail)

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE 1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL

GATE 2 — Style Compliance
Bold in body: NONE FOUND | [location]
Em dashes: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [location]
Banned words: NONE FOUND | [word + location]
Paragraph overlength: NONE FOUND | [location + word count]
Heading overlength: NONE FOUND | [heading + word count]
List quota: [N used of N allowed]
Status: PASS | FAIL

GATE 3 — Evidence Integrity
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
Status: PASS | FAIL

GATE 4 — FAQ intent: PENDING

GATE 5 — Anchor Visibility
AF-01 location: [section + position]
AF-02 location: [section + position]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL

Overall: APPROVED TO PROCEED | BLOCKED

---

### STAGE 5 — FAQ Block (5-7 questions)

Each question: buyer-decision-stage only, one specific number/condition/constraint in answer, under 50 words, zero banned words.

Score each: Commercial intent (30%) + Info gain (25%) + Specificity (25%) + Schema-ready (20%). Rewrite any below 60.

Run Gate 4 on FAQ output.

---

### STAGE 6 — Publish Package

Deliver in labelled sections: RANK MATH PACK / TL;DR / ARTICLE BODY / FAQ BLOCK / URL BOX / AF SCORECARD / VERDICT

---

**TOPIC:** CustomGPT.ai vs Zendesk AI

Begin with Stage 1 now.

---
---
---

## CHAT 3 — CustomGPT vs Voiceflow

You are running the Jarvis Auto article production system for CustomGPT.ai.

Follow every instruction below exactly. Do not skip stages. Do not summarise instructions back to me. Just run them.

---

### FIXED DEFAULTS — apply to every article, no exceptions

**Persona:** Operations manager or IT lead, 50-500 person company, evaluating AI tools for customer support or internal knowledge management. Desktop user. Intermediate expertise. Close to a buying decision.

**Style constraints (always on):**
- No bold text in article body (Rank Math pack exempt)
- No em dashes anywhere in body
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words, default ~20
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

**CTA:** https://app.customgpt.ai/register/
**Client:** CustomGPT.ai

---

### STAGE 1 — SERP Research (silent, no output)

Search the topic. Map the SERP floor. Find the gap.

Source priority:
1. CustomGPT official docs, pricing, limits pages
2. Voiceflow official pricing and docs
3. G2 / Capterra verified reviews for both tools
4. Third-party comparisons already published

Identify:
- AF-01 (data-point): Priority candidate: Voiceflow charges per workspace seat — a 5-person team building one bot pays for 5 seats. Verify current Voiceflow seat pricing and what's included per tier. Also check AI credit billing (separate from seat cost). CustomGPT charges per agent, not per user.
- AF-02 (thought-leadership): Priority candidate: Voiceflow is a conversation design tool — you design the flow, then add AI. CustomGPT is a document ingestion tool — you add your data, and the AI handles the flow. Buyers who choose Voiceflow are betting on their ability to maintain conversation logic over time. Buyers who choose CustomGPT are betting on their content quality. These are fundamentally different bets.

If no strong AF-01 after research: stop and ask.

---

### CHECKPOINT 1 — You must stop here and wait for my reply before writing anything.

Output this block exactly:

════════════════════════════════
CHECKPOINT 1 — Approve before writing
════════════════════════════════

ANCHOR LOCKED

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL or named source]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE H1: [your preferred title]
  CHANGE ANCHOR: [your preferred data point or angle]
════════════════════════════════

---

### CHECKPOINT 2 — After I approve Checkpoint 1, build outline silently then output this block. Wait for my reply.

════════════════════════════════
CHECKPOINT 2 — Approve outline before writing
════════════════════════════════

OUTLINE

H1: [title]
Short Answer: [max 50 words]

[Full H2/H3 structure — mark [ANCHOR] and [TL] sections]

H2: FAQ
H2: Conclusion
H2: Facts and sources

List-section quota: [N H2s → max N allowed, using N]
Anchor placement: [section]
Thought-leadership placement: [section]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE: [feedback]
════════════════════════════════

---

### STAGE 3 — Write full article after Checkpoint 2 approved

Requirements:
1. Short Answer first (max 50 words)
2. Follow approved outline exactly
3. Every H2: Action/steps OR Explanatory template
4. All paragraphs 15-40 words
5. Exactly one real example section
6. AF-01 in body text, not just metadata
7. AF-02 reads as genuine practitioner voice
8. Facts and sources: 3-7 bullets with Publisher + URL + Date
9. Rank Math SEO pack at end

Immediately run Stage 4 after writing without stopping.

---

### STAGE 4 — Critic Gate (auto-runs, show full audit trail)

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE 1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL

GATE 2 — Style Compliance
Bold in body: NONE FOUND | [location]
Em dashes: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [location]
Banned words: NONE FOUND | [word + location]
Paragraph overlength: NONE FOUND | [location + word count]
Heading overlength: NONE FOUND | [heading + word count]
List quota: [N used of N allowed]
Status: PASS | FAIL

GATE 3 — Evidence Integrity
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
Status: PASS | FAIL

GATE 4 — FAQ intent: PENDING

GATE 5 — Anchor Visibility
AF-01 location: [section + position]
AF-02 location: [section + position]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL

Overall: APPROVED TO PROCEED | BLOCKED

---

### STAGE 5 — FAQ Block (5-7 questions)

Each question: buyer-decision-stage only, one specific number/condition/constraint in answer, under 50 words, zero banned words.

Score each: Commercial intent (30%) + Info gain (25%) + Specificity (25%) + Schema-ready (20%). Rewrite any below 60.

Run Gate 4 on FAQ output.

---

### STAGE 6 — Publish Package

Deliver in labelled sections: RANK MATH PACK / TL;DR / ARTICLE BODY / FAQ BLOCK / URL BOX / AF SCORECARD / VERDICT

---

**TOPIC:** CustomGPT.ai vs Voiceflow

Begin with Stage 1 now.

---
---
---

## CHAT 4 — CustomGPT vs Tidio

You are running the Jarvis Auto article production system for CustomGPT.ai.

Follow every instruction below exactly. Do not skip stages. Do not summarise instructions back to me. Just run them.

---

### FIXED DEFAULTS — apply to every article, no exceptions

**Persona:** Operations manager or IT lead, 50-500 person company, evaluating AI tools for customer support or internal knowledge management. Desktop user. Intermediate expertise. Close to a buying decision.

**Style constraints (always on):**
- No bold text in article body (Rank Math pack exempt)
- No em dashes anywhere in body
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words, default ~20
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

**CTA:** https://app.customgpt.ai/register/
**Client:** CustomGPT.ai

---

### STAGE 1 — SERP Research (silent, no output)

Search the topic. Map the SERP floor. Find the gap.

Source priority:
1. CustomGPT official docs, pricing, limits pages
2. Tidio official pricing and Lyro AI documentation
3. G2 / Capterra verified reviews for both tools
4. Third-party comparisons already published

Identify:
- AF-01 (data-point): Priority candidate: Tidio's Lyro AI is trained on FAQ content only — it does not ingest PDFs, Word docs, or full document libraries. Verify exact Lyro source limits (number of FAQ pairs, file types supported). Also check Lyro conversation pricing — Lyro charges per conversation, not per message. Verify current rates.
- AF-02 (thought-leadership): Priority candidate: Tidio is a live chat tool with AI added on. CustomGPT is an AI platform with a chat interface. The architecture difference matters operationally — Tidio routes unresolved Lyro conversations to a human agent inbox, CustomGPT routes them to your support stack via integration. Businesses that outgrow Lyro's FAQ ceiling face a migration, not an upgrade.

If no strong AF-01 after research: stop and ask.

---

### CHECKPOINT 1 — You must stop here and wait for my reply before writing anything.

Output this block exactly:

════════════════════════════════
CHECKPOINT 1 — Approve before writing
════════════════════════════════

ANCHOR LOCKED

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL or named source]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE H1: [your preferred title]
  CHANGE ANCHOR: [your preferred data point or angle]
════════════════════════════════

---

### CHECKPOINT 2 — After I approve Checkpoint 1, build outline silently then output this block. Wait for my reply.

════════════════════════════════
CHECKPOINT 2 — Approve outline before writing
════════════════════════════════

OUTLINE

H1: [title]
Short Answer: [max 50 words]

[Full H2/H3 structure — mark [ANCHOR] and [TL] sections]

H2: FAQ
H2: Conclusion
H2: Facts and sources

List-section quota: [N H2s → max N allowed, using N]
Anchor placement: [section]
Thought-leadership placement: [section]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE: [feedback]
════════════════════════════════

---

### STAGE 3 — Write full article after Checkpoint 2 approved

Requirements:
1. Short Answer first (max 50 words)
2. Follow approved outline exactly
3. Every H2: Action/steps OR Explanatory template
4. All paragraphs 15-40 words
5. Exactly one real example section
6. AF-01 in body text, not just metadata
7. AF-02 reads as genuine practitioner voice
8. Facts and sources: 3-7 bullets with Publisher + URL + Date
9. Rank Math SEO pack at end

Immediately run Stage 4 after writing without stopping.

---

### STAGE 4 — Critic Gate (auto-runs, show full audit trail)

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE 1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL

GATE 2 — Style Compliance
Bold in body: NONE FOUND | [location]
Em dashes: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [location]
Banned words: NONE FOUND | [word + location]
Paragraph overlength: NONE FOUND | [location + word count]
Heading overlength: NONE FOUND | [heading + word count]
List quota: [N used of N allowed]
Status: PASS | FAIL

GATE 3 — Evidence Integrity
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
Status: PASS | FAIL

GATE 4 — FAQ intent: PENDING

GATE 5 — Anchor Visibility
AF-01 location: [section + position]
AF-02 location: [section + position]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL

Overall: APPROVED TO PROCEED | BLOCKED

---

### STAGE 5 — FAQ Block (5-7 questions)

Each question: buyer-decision-stage only, one specific number/condition/constraint in answer, under 50 words, zero banned words.

Score each: Commercial intent (30%) + Info gain (25%) + Specificity (25%) + Schema-ready (20%). Rewrite any below 60.

Run Gate 4 on FAQ output.

---

### STAGE 6 — Publish Package

Deliver in labelled sections: RANK MATH PACK / TL;DR / ARTICLE BODY / FAQ BLOCK / URL BOX / AF SCORECARD / VERDICT

---

**TOPIC:** CustomGPT.ai vs Tidio

Begin with Stage 1 now.

---
---
---

## CHAT 5 — CustomGPT vs Dify

You are running the Jarvis Auto article production system for CustomGPT.ai.

Follow every instruction below exactly. Do not skip stages. Do not summarise instructions back to me. Just run them.

---

### FIXED DEFAULTS — apply to every article, no exceptions

**Persona:** Operations manager or IT lead, 50-500 person company, evaluating AI tools for customer support or internal knowledge management. Desktop user. Intermediate expertise. Close to a buying decision.

**Style constraints (always on):**
- No bold text in article body (Rank Math pack exempt)
- No em dashes anywhere in body
- No nested bullet lists
- No brackets or parentheses in any heading
- H2/H3 max 6 words
- Paragraphs 15-40 words, default ~20
- List quota: max 1 list-section per 6 H2s
- Banned words: delve, tapestry, pivotal, "it's worth noting", "in conclusion", "dive into", "game-changer", "revolutionize", "cutting-edge", "seamlessly"
- No placeholder URLs — every link must be real and verified

**CTA:** https://app.customgpt.ai/register/
**Client:** CustomGPT.ai

---

### STAGE 1 — SERP Research (silent, no output)

Search the topic. Map the SERP floor. Find the gap.

Source priority:
1. CustomGPT official docs, pricing, limits pages
2. Dify official docs, pricing, GitHub repo (self-hosted vs cloud)
3. G2 / Capterra verified reviews for both tools
4. Developer community comparisons (Reddit, Hacker News, dev blogs)

Identify:
- AF-01 (data-point): Priority candidate: Dify self-hosted on AWS or Azure for a production RAG app with moderate traffic typically runs $200-800/month in infrastructure costs before any development time. Verify with current AWS/Azure pricing for the compute and storage profile a typical RAG deployment needs. Also check Dify Cloud pricing vs CustomGPT Standard.
- AF-02 (thought-leadership): Priority candidate: The open-source vs managed SaaS decision is not a cost decision — it's a staffing decision. Dify self-hosted requires someone to own infrastructure, updates, and uptime. Most operations teams at 50-500 person companies don't have that person. The "free" open-source option has a hidden salary cost that never appears in a vendor comparison table.

If no strong AF-01 after research: stop and ask.

---

### CHECKPOINT 1 — You must stop here and wait for my reply before writing anything.

Output this block exactly:

════════════════════════════════
CHECKPOINT 1 — Approve before writing
════════════════════════════════

ANCHOR LOCKED

AF-01 (data-point):
[One specific, verifiable sentence]
Source: [URL or named source]

AF-02 (thought-leadership):
[One genuine practitioner insight]
Why it's non-obvious: [one sentence]

H1 PROPOSED: [title]
Slug: [slug]
Intent: Compare

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE H1: [your preferred title]
  CHANGE ANCHOR: [your preferred data point or angle]
════════════════════════════════

---

### CHECKPOINT 2 — After I approve Checkpoint 1, build outline silently then output this block. Wait for my reply.

════════════════════════════════
CHECKPOINT 2 — Approve outline before writing
════════════════════════════════

OUTLINE

H1: [title]
Short Answer: [max 50 words]

[Full H2/H3 structure — mark [ANCHOR] and [TL] sections]

H2: FAQ
H2: Conclusion
H2: Facts and sources

List-section quota: [N H2s → max N allowed, using N]
Anchor placement: [section]
Thought-leadership placement: [section]

Evidence (top 5):
- [Publisher | URL | What it supports]

════════════════════════════════
Reply:
  APPROVED — write the article
  CHANGE: [feedback]
════════════════════════════════

---

### STAGE 3 — Write full article after Checkpoint 2 approved

Requirements:
1. Short Answer first (max 50 words)
2. Follow approved outline exactly
3. Every H2: Action/steps OR Explanatory template
4. All paragraphs 15-40 words
5. Exactly one real example section
6. AF-01 in body text, not just metadata
7. AF-02 reads as genuine practitioner voice
8. Facts and sources: 3-7 bullets with Publisher + URL + Date
9. Rank Math SEO pack at end

Immediately run Stage 4 after writing without stopping.

---

### STAGE 4 — Critic Gate (auto-runs, show full audit trail)

════════════════════════════════
CRITIC GATE — AUDIT TRAIL
════════════════════════════════

GATE 1 — Conversion
AF-01 present in body: YES/NO — [quote exact sentence]
AF-02 present in body: YES/NO — [quote exact sentence]
Cynical buyer test: PASS/FAIL — [one sentence evidence]
Status: PASS | FAIL

GATE 2 — Style Compliance
Bold in body: NONE FOUND | [location]
Em dashes: NONE FOUND | [location]
Nested lists: NONE FOUND | [location]
Brackets in headings: NONE FOUND | [location]
Banned words: NONE FOUND | [word + location]
Paragraph overlength: NONE FOUND | [location + word count]
Heading overlength: NONE FOUND | [heading + word count]
List quota: [N used of N allowed]
Status: PASS | FAIL

GATE 3 — Evidence Integrity
Placeholder URLs: NONE FOUND | [location]
Unattributed stats: NONE FOUND | [claim]
Status: PASS | FAIL

GATE 4 — FAQ intent: PENDING

GATE 5 — Anchor Visibility
AF-01 location: [section + position]
AF-02 location: [section + position]
Prominence: PROMINENT | BURIED
Status: PASS | FAIL

Overall: APPROVED TO PROCEED | BLOCKED

---

### STAGE 5 — FAQ Block (5-7 questions)

Each question: buyer-decision-stage only, one specific number/condition/constraint in answer, under 50 words, zero banned words.

Score each: Commercial intent (30%) + Info gain (25%) + Specificity (25%) + Schema-ready (20%). Rewrite any below 60.

Run Gate 4 on FAQ output.

---

### STAGE 6 — Publish Package

Deliver in labelled sections: RANK MATH PACK / TL;DR / ARTICLE BODY / FAQ BLOCK / URL BOX / AF SCORECARD / VERDICT

---

**TOPIC:** CustomGPT.ai vs Dify

Begin with Stage 1 now.
