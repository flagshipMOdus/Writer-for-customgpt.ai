# Writer for CustomGPT.ai

Jarvis — the CustomGPT.ai content production system.

Built to produce comparison articles and AEO-optimised content that converts
cynical, qualified buyers. Every article must satisfy 8 AF criteria before publish.

---

## Repository Structure

```
/skills          — Install these in Claude Settings → Skills
/briefs          — Paste these into fresh Claude chats to run articles
README.md
```

---

## Skills

| Skill | Purpose |
|-------|---------|
| `jarvis-auto` | Main article runner — 5 approval gates, full CMS package output |
| `jarvis-verifier` | Independent post-production audit against every rule |
| `aeo-qa-writer` | AEO content workflow — Phase A through D |
| `content-critic` | Anti-sycophancy quality gate — 6 critique gates |
| `jarvis-goals` | 8 AF criteria — definition of done for every article |
| `jarvis-production-system` | Full 7-stage production pipeline |
| `jarvis-info-gain` | SERP gap + information gain anchor research |
| `jarvis-next-command` | Session orchestration — tracks in-flight articles |
| `jarvis-serp-explorer` | Fast SERP gap agent for morning research pass |

### How to Install Skills

1. Go to Claude.ai → Settings → Skills
2. Upload each `.skill` file from the `/skills` folder
3. Skills auto-load when triggered by the descriptions in each file

---

## Comparison Article Briefs

Each brief in `/briefs` is a self-contained prompt for a fresh Claude chat.
Copy everything from START to END and paste as your first message.

| Brief | Topic |
|-------|-------|
| `01-customgpt-vs-intercom-fin.md` | CustomGPT vs Intercom Fin |
| `02-customgpt-vs-zendesk-ai.md` | CustomGPT vs Zendesk AI |
| `03-customgpt-vs-voiceflow.md` | CustomGPT vs Voiceflow |
| `04-customgpt-vs-tidio.md` | CustomGPT vs Tidio |
| `05-customgpt-vs-dify.md` | CustomGPT vs Dify |
| `all-comparison-briefs.md` | All 5 briefs in one file |

---

## The 5 Gate Phrases

Every article produced by `jarvis-auto` uses these exact phrases to advance:

```
Gate 1 unlock: approved - write outline
Gate 2 unlock: approved - write the content
Gate 3 unlock: approved - run critic
Gate 4 unlock: approved - write faq
Gate 5 unlock: approved - publish
```

---

## AF Criteria (Definition of Done)

All 8 must be SATISFIED before any article is published:

- AF-01: One verified data-point not on SERP floor
- AF-02: One genuine practitioner thought-leadership insight
- AF-03: Written for buyer near decision, not beginner
- AF-04: All FAQs score 60+, buyer-stage language, 5-7 questions
- AF-05: Zero style violations (no bold, no em dashes, no banned words)
- AF-06: All facts sourced and dated, no placeholder URLs
- AF-07: Rank Math pack + TL;DR + FAQ CSS block + JSON-LD schema all present
- AF-08: No cannibalization with existing CustomGPT articles

---

## CTA

All articles use: `https://app.customgpt.ai/register/`
